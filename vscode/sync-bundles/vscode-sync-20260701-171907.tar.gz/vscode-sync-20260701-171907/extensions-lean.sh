#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ALL_FILE="${ROOT_DIR}/extensions.all.txt"
ACTIVE_FILE="${ROOT_DIR}/extensions.active-noncosmetic.txt"
VISUAL_FILE="${ROOT_DIR}/extensions.visual.txt"
GLOBAL_FILE="${ROOT_DIR}/extensions.global-defaults.txt"
PORTABLE_FILE="${ROOT_DIR}/extensions.portable.txt"
LOCK_FILE="${ROOT_DIR}/extensions.lock.txt"
FONTS_FILE="${ROOT_DIR}/fonts.required.txt"
FONTS_REPORT_FILE="${ROOT_DIR}/fonts.presence.txt"
SYNC_DIR="${ROOT_DIR}/portable-sync"
PROFILE_MAP_FILE="${ROOT_DIR}/profile-map.env"
PUBLISH_REPO_DIR_DEFAULT="${HOME}/devenv"
PUBLISH_SUBDIR_DEFAULT="vscode/sync-bundles"

# Resolve CLI across common installs.
if command -v code-insiders >/dev/null 2>&1; then
  VSCODE_CLI="code-insiders"
elif command -v code >/dev/null 2>&1; then
  VSCODE_CLI="code"
else
  VSCODE_CLI=""
fi

load_profile_map_defaults() {
  [[ -f "$PROFILE_MAP_FILE" ]] || return 0

  local PROFILE_NAME=""
  local PROFILE_SETTINGS_FILE=""
  local PROFILE_KEYBINDINGS_FILE=""
  local PROFILE_SNIPPETS_DIR=""

  # shellcheck disable=SC1090
  source "$PROFILE_MAP_FILE"

  if [[ -z "${VSCODE_PROFILE_NAME:-}" && -n "$PROFILE_NAME" ]]; then
    export VSCODE_PROFILE_NAME="$PROFILE_NAME"
  fi
  if [[ -z "${VSCODE_PROFILE_SETTINGS_FILE:-}" && -n "$PROFILE_SETTINGS_FILE" ]]; then
    export VSCODE_PROFILE_SETTINGS_FILE="$PROFILE_SETTINGS_FILE"
  fi
  if [[ -z "${VSCODE_PROFILE_KEYBINDINGS_FILE:-}" && -n "$PROFILE_KEYBINDINGS_FILE" ]]; then
    export VSCODE_PROFILE_KEYBINDINGS_FILE="$PROFILE_KEYBINDINGS_FILE"
  fi
  if [[ -z "${VSCODE_PROFILE_SNIPPETS_DIR:-}" && -n "$PROFILE_SNIPPETS_DIR" ]]; then
    export VSCODE_PROFILE_SNIPPETS_DIR="$PROFILE_SNIPPETS_DIR"
  fi
}

init_profile_map() {
  if [[ -f "$PROFILE_MAP_FILE" ]]; then
    echo "Profile map already exists: $PROFILE_MAP_FILE"
    return 0
  fi

  cat > "$PROFILE_MAP_FILE" <<'EOF'
# One-time profile path map for portable sync exports/imports.
# Keep values quoted when they include spaces.

# Friendly profile label (optional)
PROFILE_NAME="Main (Base-26)"

# Exact active profile artifacts to capture on sync-export.
# Examples:
# Linux VS Code Insiders: "/home/<you>/.config/Code - Insiders/User/settings.json"
# Windows VS Code Insiders: "C:/Users/<you>/AppData/Roaming/Code - Insiders/User/settings.json"
PROFILE_SETTINGS_FILE=""
PROFILE_KEYBINDINGS_FILE=""
PROFILE_SNIPPETS_DIR=""
EOF

  echo "Created: $PROFILE_MAP_FILE"
  echo "Update PROFILE_SETTINGS_FILE / PROFILE_KEYBINDINGS_FILE / PROFILE_SNIPPETS_DIR once, then re-run sync-export."
}

load_profile_map_defaults

write_lines() {
  local file_path="$1"
  shift
  : > "$file_path"
  for item in "$@"; do
    [[ -z "$item" ]] && continue
    printf '%s\n' "$item" >> "$file_path"
  done
}

collect_extensions_fallback() {
  local ext_root
  local roots=(
    "${HOME}/.vscode-server-insiders/extensions"
    "${HOME}/.vscode-insiders/extensions"
    "${HOME}/.vscode/extensions"
    "${HOME}/.cursor-server/extensions"
    "${HOME}/.cursor/extensions"
  )

  : > "$ALL_FILE"
  for ext_root in "${roots[@]}"; do
    [[ -d "$ext_root" ]] || continue
    find "$ext_root" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' \
      | sed -E 's/-[0-9][0-9A-Za-z.+_-]*$//' >> "$ALL_FILE"
  done
  sort -u "$ALL_FILE" -o "$ALL_FILE"
}

export_extensions() {
  if [[ -z "$VSCODE_CLI" ]]; then
    echo "VS Code CLI not found; using folder scan fallback."
    collect_extensions_fallback
    echo "Wrote (fallback): $ALL_FILE"
    return
  fi

  if "$VSCODE_CLI" --list-extensions > "$ALL_FILE" 2>/dev/null; then
    sort -u "$ALL_FILE" -o "$ALL_FILE"
    echo "Wrote: $ALL_FILE"
    return
  fi

  echo "VS Code CLI could not list extensions in this shell; using folder scan fallback."
  collect_extensions_fallback
  echo "Wrote (fallback): $ALL_FILE"
}

visual_ids=(
  "davidbabel.vscode-simpler-icons"
  "tal7aouy.icons"
  "cweijan.vscode-office"
)

global_default_ids=(
  # Required for devenv's vscode_custom_css.imports profile feature
  "be5invis.vscode-custom-css"

  # Core editor and language tooling
  "streetsidesoftware.code-spell-checker"
  "eamodio.gitlens"
  "donjayamanne.githistory"
  "donjayamanne.git-extension-pack"
  "github.vscode-github-actions"
  "github.vscode-pull-request-github"
  "ziyasal.vscode-open-in-github"
  "codezombiech.gitignore"

  # Python / notebooks
  "ms-python.python"
  "ms-python.vscode-pylance"
  "ms-python.debugpy"
  "ms-python.vscode-python-envs"
  "njpwerner.autodocstring"
  "njqdev.vscode-python-typehint"
  "sourcery.sourcery"
  "batisteo.vscode-django"
  "littlefoxteam.vscode-python-test-adapter"
  "hbenl.vscode-test-explorer"
  "ms-vscode.test-adapter-converter"
  "kaih2o.python-resource-monitor"
  "almenon.arepl"
  "ms-toolsai.jupyter"
  "ms-toolsai.jupyter-renderers"
  "ms-toolsai.jupyter-hub"
  "ms-toolsai.vscode-jupyter-cell-tags"
  "ms-toolsai.vscode-jupyter-powertoys"
  "ms-toolsai.vscode-jupyter-slideshow"

  # Containers / Docker / remote workloads
  "docker.docker"
  "ms-azuretools.vscode-docker"
  "ms-azuretools.vscode-containers"
  "formulahendry.docker-explorer"

  # Data / SQL / files
  "mtxr.sqltools"
  "mtxr.sqltools-driver-pg"
  "kj.sqltools-driver-redshift"
  "bstruct.vscode-bigquery"
  "evidence.sqltools-bigquery-driver"
  "minodisk.bigquery-runner"
  "dbcode.dbcode"
  "mechatroner.rainbow-csv"
  "repreng.csv"
  "grapecity.gc-excelviewer"

  # Markdown / docs / previews
  "yzhang.markdown-all-in-one"
  "shd101wyy.markdown-preview-enhanced"
  "davidanson.vscode-markdownlint"
  "mdickin.markdown-shortcuts"
  "bierner.markdown-mermaid"
  "bierner.markdown-footnotes"
  "hancel.markdown-image"
  "mintlify.document"
  "chrischinchilla.vscode-pandoc"
  "yzane.markdown-pdf"
  "tom-latham.markdown-pdf-plus"
  "deadpoulpe.custom-md-pdf"
  "zhyong10.markdown-html"
  "nuxt.mdc"

  # Misc / productivity / AI
  "ms-vscode.powershell"
  "naveenvignesh5nv.html-live-server"
  "xirider.livecode"
  "oderwat.indent-rainbow"
  "ctcuff.font-preview"
  "openai.chatgpt"
  "anthropic.claude-code"
)

build_active_noncosmetic() {
  if [[ ! -f "$ALL_FILE" ]]; then
    echo "Missing $ALL_FILE. Run: $0 export" >&2
    exit 1
  fi

  local visual_filter
  visual_filter="$(mktemp)"
  trap "rm -f '$visual_filter'" RETURN
  write_lines "$visual_filter" "${visual_ids[@]}"
  grep -vxFf "$visual_filter" "$ALL_FILE" > "$ACTIVE_FILE" || true
  echo "Wrote: $ACTIVE_FILE"
}

build_visual_pack() {
  write_lines "$VISUAL_FILE" "${visual_ids[@]}"
  echo "Wrote: $VISUAL_FILE"
}

build_global_defaults() {
  write_lines "$GLOBAL_FILE" "${global_default_ids[@]}"
  echo "Wrote: $GLOBAL_FILE"
}

build_portable_pack() {
  build_global_defaults >/dev/null
  build_visual_pack >/dev/null
  sort -u "$GLOBAL_FILE" "$VISUAL_FILE" > "$PORTABLE_FILE"
  echo "Wrote: $PORTABLE_FILE"
}

build_extension_lock() {
  node - <<'NODE' "$LOCK_FILE" "$HOME"
const fs = require('fs');
const path = require('path');

const outFile = process.argv[2];
const home = process.argv[3];
const roots = [
  path.join(home, '.vscode-server-insiders/extensions'),
  path.join(home, '.vscode-server/extensions'),
  path.join(home, '.vscode-insiders/extensions'),
  path.join(home, '.vscode/extensions'),
  path.join(home, '.cursor-server/extensions'),
  path.join(home, '.cursor/extensions')
];

const byId = new Map();

for (const root of roots) {
  if (!fs.existsSync(root)) continue;
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const pkgPath = path.join(root, entry.name, 'package.json');
    if (!fs.existsSync(pkgPath)) continue;
    try {
      const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
      if (!pkg.publisher || !pkg.name || !pkg.version) continue;
      const id = `${pkg.publisher}.${pkg.name}`.toLowerCase();
      const version = `${pkg.version}`;
      const prev = byId.get(id);
      if (!prev || version.localeCompare(prev.version, undefined, { numeric: true, sensitivity: 'base' }) > 0) {
        byId.set(id, { version });
      }
    } catch {
      // Ignore malformed package metadata.
    }
  }
}

const lines = [...byId.entries()]
  .sort((a, b) => a[0].localeCompare(b[0]))
  .map(([id, data]) => `${id}@${data.version}`);

fs.writeFileSync(outFile, lines.join('\n') + (lines.length ? '\n' : ''), 'utf8');
console.log(`Wrote: ${outFile}`);
NODE
}

copy_if_exists() {
  local src="$1"
  local dst="$2"
  if [[ -f "$src" ]]; then
    mkdir -p "$(dirname "$dst")"
    cp "$src" "$dst"
  fi
}

copy_dir_if_exists() {
  local src="$1"
  local dst="$2"
  if [[ -d "$src" ]]; then
    mkdir -p "$(dirname "$dst")"
    cp -R "$src" "$dst"
  fi
}

capture_user_data_roots() {
  local bundle_dir="$1"
  local user_data_dir="$bundle_dir/user-data"
  mkdir -p "$user_data_dir"

  local labels=(
    "code-insiders-user|${HOME}/.config/Code - Insiders/User"
    "code-user|${HOME}/.config/Code/User"
    "cursor-user|${HOME}/.config/Cursor/User"
    "vscode-server-insiders-user|${HOME}/.vscode-server-insiders/data/User"
    "vscode-server-user|${HOME}/.vscode-server/data/User"
  )

  : > "$bundle_dir/user-data-index.txt"
  local item label root target
  for item in "${labels[@]}"; do
    label="${item%%|*}"
    root="${item#*|}"
    [[ -d "$root" ]] || continue

    target="$user_data_dir/$label"
    mkdir -p "$target"

    copy_if_exists "$root/settings.json" "$target/settings.json"
    copy_if_exists "$root/keybindings.json" "$target/keybindings.json"
    copy_if_exists "$root/mcp.json" "$target/mcp.json"
    copy_dir_if_exists "$root/snippets" "$target/snippets"
    copy_dir_if_exists "$root/profiles" "$target/profiles"

    echo "$label|$root" >> "$bundle_dir/user-data-index.txt"
  done
}

detect_active_profile_guess() {
  local bundle_dir="$1"
  local active_guess_file="$bundle_dir/active-profile-guess.txt"
  : > "$active_guess_file"

  local item label root profiles_dir latest
  local labels=(
    "code-insiders-user|${HOME}/.config/Code - Insiders/User"
    "code-user|${HOME}/.config/Code/User"
    "cursor-user|${HOME}/.config/Cursor/User"
    "vscode-server-insiders-user|${HOME}/.vscode-server-insiders/data/User"
    "vscode-server-user|${HOME}/.vscode-server/data/User"
  )

  for item in "${labels[@]}"; do
    label="${item%%|*}"
    root="${item#*|}"
    profiles_dir="$root/profiles"
    [[ -d "$profiles_dir" ]] || continue

    latest="$(find "$profiles_dir" -mindepth 1 -maxdepth 1 -type d -printf '%T@ %f\n' 2>/dev/null | sort -nr | head -n 1 | awk '{print $2}')"
    [[ -n "$latest" ]] && echo "$label|$latest" >> "$active_guess_file"
  done
}

build_all_lists() {
  export_extensions
  build_active_noncosmetic
  build_visual_pack
  build_global_defaults
  build_portable_pack
  build_extension_lock
  build_fonts_presence_report
}

build_fonts_presence_report() {
  : > "$FONTS_REPORT_FILE"

  if [[ ! -f "$FONTS_FILE" ]]; then
    echo "No fonts manifest found at $FONTS_FILE" >> "$FONTS_REPORT_FILE"
    echo "Wrote: $FONTS_REPORT_FILE"
    return
  fi

  if ! command -v fc-list >/dev/null 2>&1; then
    echo "fontconfig not available (fc-list not found). Could not check installed fonts." >> "$FONTS_REPORT_FILE"
    echo "Wrote: $FONTS_REPORT_FILE"
    return
  fi

  local status
  local font
  while IFS= read -r font || [[ -n "$font" ]]; do
    font="${font%%#*}"
    font="$(echo "$font" | xargs)"
    [[ -z "$font" ]] && continue
    if fc-list : family | tr ',' '\n' | sed 's/^ *//; s/ *$//' | grep -Fxqi "$font"; then
      status="present"
    else
      status="missing"
    fi
    printf '%s\t%s\n' "$status" "$font" >> "$FONTS_REPORT_FILE"
  done < "$FONTS_FILE"

  echo "Wrote: $FONTS_REPORT_FILE"
}

capture_profile_settings() {
  local bundle_dir="$1"
  local profile_source="${VSCODE_PROFILE_SETTINGS_FILE:-}"
  local copied=0

  if [[ -n "$profile_source" && -f "$profile_source" ]]; then
    cp "$profile_source" "$bundle_dir/profile.settings.json"
    copied=1
  fi

  # If no explicit profile settings file is provided, capture main user settings as baseline.
  if [[ $copied -eq 0 ]]; then
    local main_candidates=(
      "${HOME}/.config/Code - Insiders/User/settings.json"
      "${HOME}/.config/Code/User/settings.json"
    )
    local candidate
    for candidate in "${main_candidates[@]}"; do
      if [[ -f "$candidate" ]]; then
        cp "$candidate" "$bundle_dir/main-user.settings.json"
        copied=1
        break
      fi
    done
  fi

  if [[ $copied -eq 0 ]]; then
    echo "Note: no profile/user settings file captured."
    echo "Set PROFILE_SETTINGS_FILE in $PROFILE_MAP_FILE or export VSCODE_PROFILE_SETTINGS_FILE."
  fi
}

restore_user_data_roots() {
  local import_dir="$1"
  local user_data_dir="$import_dir/user-data"
  [[ -d "$user_data_dir" ]] || return 0

  local item label target source
  local labels=(
    "code-insiders-user|${HOME}/.config/Code - Insiders/User"
    "code-user|${HOME}/.config/Code/User"
    "cursor-user|${HOME}/.config/Cursor/User"
    "vscode-server-insiders-user|${HOME}/.vscode-server-insiders/data/User"
    "vscode-server-user|${HOME}/.vscode-server/data/User"
  )

  for item in "${labels[@]}"; do
    label="${item%%|*}"
    target="${item#*|}"
    source="$user_data_dir/$label"
    [[ -d "$source" ]] || continue

    mkdir -p "$target"
    copy_if_exists "$source/settings.json" "$target/settings.json"
    copy_if_exists "$source/keybindings.json" "$target/keybindings.json"
    copy_if_exists "$source/mcp.json" "$target/mcp.json"
    copy_dir_if_exists "$source/snippets" "$target/snippets"
    copy_dir_if_exists "$source/profiles" "$target/profiles"
  done
}

install_from_list_file() {
  local list_file="$1"
  if [[ -z "$VSCODE_CLI" ]]; then
    echo "VS Code CLI not found; cannot install extensions automatically." >&2
    exit 1
  fi

  while IFS= read -r ext; do
    ext="${ext%%#*}"
    ext="$(echo "$ext" | xargs)"
    [[ -z "$ext" ]] && continue
    echo "Installing: $ext"
    "$VSCODE_CLI" --install-extension "$ext" || true
  done < "$list_file"
}

install_from_lock_file() {
  local list_file="$1"
  if [[ -z "$VSCODE_CLI" ]]; then
    echo "VS Code CLI not found; cannot install locked extensions automatically." >&2
    exit 1
  fi

  while IFS= read -r ext; do
    ext="${ext%%#*}"
    ext="$(echo "$ext" | xargs)"
    [[ -z "$ext" ]] && continue
    echo "Installing locked: $ext"
    if ! "$VSCODE_CLI" --install-extension "$ext" --force; then
      local id_only="${ext%@*}"
      echo "WARN: failed locked install for $ext; falling back to latest for $id_only"
      "$VSCODE_CLI" --install-extension "$id_only" --force || true
    fi
  done < "$list_file"
}

sync_export_bundle() {
  local stamp
  local bundle_dir
  local tar_path

  stamp="$(date +%Y%m%d-%H%M%S)"
  bundle_dir="${SYNC_DIR}/vscode-sync-${stamp}"
  tar_path="${SYNC_DIR}/vscode-sync-${stamp}.tar.gz"

  mkdir -p "$bundle_dir"
  build_all_lists

  cp "$ALL_FILE" "$bundle_dir/"
  cp "$ACTIVE_FILE" "$bundle_dir/"
  cp "$VISUAL_FILE" "$bundle_dir/"
  cp "$GLOBAL_FILE" "$bundle_dir/"
  cp "$PORTABLE_FILE" "$bundle_dir/"
  cp "$LOCK_FILE" "$bundle_dir/"
  [[ -f "$FONTS_FILE" ]] && cp "$FONTS_FILE" "$bundle_dir/"
  [[ -f "$FONTS_REPORT_FILE" ]] && cp "$FONTS_REPORT_FILE" "$bundle_dir/"
  [[ -f "${ROOT_DIR}/tasks.json" ]] && cp "${ROOT_DIR}/tasks.json" "$bundle_dir/"
  [[ -f "${ROOT_DIR}/settings.json" ]] && cp "${ROOT_DIR}/settings.json" "$bundle_dir/"
  cp "${ROOT_DIR}/scripts/extensions-lean.sh" "$bundle_dir/"
  [[ -f "$PROFILE_MAP_FILE" ]] && cp "$PROFILE_MAP_FILE" "$bundle_dir/"

  capture_user_data_roots "$bundle_dir"
  detect_active_profile_guess "$bundle_dir"
  capture_profile_settings "$bundle_dir"

  cat > "$bundle_dir/sync-manifest.txt" <<EOF
created_at=${stamp}
host=$(hostname)
root=${ROOT_DIR}
notes=Run: bash extensions-lean.sh sync-import <bundle.tar.gz|bundle_dir>
profile_name=${VSCODE_PROFILE_NAME:-}
EOF

  mkdir -p "$SYNC_DIR"
  tar -C "$SYNC_DIR" -czf "$tar_path" "$(basename "$bundle_dir")"

  echo "Sync bundle directory: $bundle_dir"
  echo "Sync bundle archive:   $tar_path"

  prune_local_bundles
}

prune_local_bundles() {
  local keep="${SYNC_KEEP_LOCAL:-10}"
  local -a dirs
  mapfile -t dirs < <(ls -1d "${SYNC_DIR}"/vscode-sync-*/ 2>/dev/null | sort)
  local total="${#dirs[@]}"
  (( total > keep )) || return 0

  local remove_count=$(( total - keep ))
  local i d
  for (( i=0; i<remove_count; i++ )); do
    d="${dirs[$i]%/}"
    rm -rf "$d" "${d}.tar.gz"
    echo "Pruned old local bundle: $(basename "$d")"
  done
}

redact_publish_tar() {
  local src_tar="$1"
  local dst_tar="$2"
  local strip_dir
  local extracted_dir

  strip_dir="$(mktemp -d)"
  tar -xzf "$src_tar" -C "$strip_dir"
  extracted_dir="$(find "$strip_dir" -mindepth 1 -maxdepth 1 -type d | head -n 1)"

  # user-data/ holds full app user dirs (mcp.json, settings.json, keybindings.json,
  # profiles/) copied verbatim from Code/Cursor. It's needed for local machine-to-machine
  # sync-import, but must never land in the public devenv repo (mcp.json commonly holds
  # inline API keys/tokens for MCP servers).
  rm -rf "$extracted_dir/user-data" "$extracted_dir/user-data-index.txt"

  tar -C "$strip_dir" -czf "$dst_tar" "$(basename "$extracted_dir")"
  rm -rf "$strip_dir"
}

sync_publish_bundle() {
  local repo_dir="${SYNC_PUBLISH_REPO_DIR:-$PUBLISH_REPO_DIR_DEFAULT}"
  local publish_subdir="${SYNC_PUBLISH_SUBDIR:-$PUBLISH_SUBDIR_DEFAULT}"
  local publish_dir="${repo_dir}/${publish_subdir}"
  local latest_tar
  local latest_base
  local published_tar
  local now

  sync_export_bundle

  latest_tar="$(ls -1 "${SYNC_DIR}"/vscode-sync-*.tar.gz 2>/dev/null | sort | tail -n 1)"
  if [[ -z "$latest_tar" ]]; then
    echo "Could not find a sync bundle tarball in $SYNC_DIR" >&2
    exit 1
  fi

  if [[ ! -d "$repo_dir" ]]; then
    echo "Publish repo not found: $repo_dir" >&2
    echo "Set SYNC_PUBLISH_REPO_DIR to override." >&2
    exit 1
  fi

  mkdir -p "$publish_dir"
  latest_base="$(basename "$latest_tar")"
  published_tar="$publish_dir/$latest_base"
  redact_publish_tar "$latest_tar" "$published_tar"
  echo "Redacted user-data/ (mcp.json, settings.json, keybindings.json, profiles/) from published bundle."

  cp "$published_tar" "$publish_dir/latest.tar.gz"
  printf '%s\n' "$latest_base" > "$publish_dir/latest.txt"

  now="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  cat > "$publish_dir/latest.json" <<EOF
{
  "latest_tarball": "$latest_base",
  "published_at_utc": "$now",
  "profile_name": "${VSCODE_PROFILE_NAME:-}",
  "source_sync_dir": "${SYNC_DIR}",
  "source_repo": "${repo_dir}"
}
EOF

  # Keep the repo's plain-text manifest (read by bootstrap-vscode-portable.sh) in sync
  # with the real portable extension set, instead of it staying a stale hand-edited stub.
  local repo_vscode_dir="${repo_dir}/vscode"
  if [[ -d "$repo_vscode_dir" && -f "$PORTABLE_FILE" ]]; then
    cp "$PORTABLE_FILE" "$repo_vscode_dir/extensions.required.txt"
    [[ -f "$LOCK_FILE" ]] && cp "$LOCK_FILE" "$repo_vscode_dir/extensions.lock.txt"
    echo "Updated repo manifest: $repo_vscode_dir/extensions.required.txt"
  fi

  echo "Published bundle: $published_tar"
  echo "Latest pointer:  $publish_dir/latest.tar.gz"
  echo "Index file:      $publish_dir/latest.json"

  prune_published_bundles "$publish_dir"
}

prune_published_bundles() {
  local publish_dir="$1"
  local keep="${SYNC_KEEP_PUBLISHED:-3}"
  local -a tars
  mapfile -t tars < <(ls -1 "${publish_dir}"/vscode-sync-*.tar.gz 2>/dev/null | sort)
  local total="${#tars[@]}"
  (( total > keep )) || return 0

  local remove_count=$(( total - keep ))
  local i
  for (( i=0; i<remove_count; i++ )); do
    rm -f "${tars[$i]}"
    echo "Pruned old published bundle: $(basename "${tars[$i]}")"
  done
}

sync_import_bundle() {
  local src="${2:-}"
  local install_flag="${3:-install-locked}"
  local temp_dir
  local import_dir

  if [[ -z "$src" ]]; then
    echo "Usage: $0 sync-import <bundle.tar.gz|bundle_dir> [install|install-locked|no-install]" >&2
    exit 1
  fi

  if [[ -f "$src" ]]; then
    temp_dir="$(mktemp -d)"
    # shellcheck disable=SC2064 -- expand temp_dir now; it's a local var and
    # would be unbound by the time this EXIT trap fires after the function returns.
    trap "rm -rf '$temp_dir'" EXIT
    tar -xzf "$src" -C "$temp_dir"
    import_dir="$(find "$temp_dir" -mindepth 1 -maxdepth 1 -type d | head -n 1)"
  elif [[ -d "$src" ]]; then
    import_dir="$src"
  else
    echo "Bundle source not found: $src" >&2
    exit 1
  fi

  [[ -f "$import_dir/extensions.all.txt" ]] && cp "$import_dir/extensions.all.txt" "$ALL_FILE"
  [[ -f "$import_dir/extensions.active-noncosmetic.txt" ]] && cp "$import_dir/extensions.active-noncosmetic.txt" "$ACTIVE_FILE"
  [[ -f "$import_dir/extensions.visual.txt" ]] && cp "$import_dir/extensions.visual.txt" "$VISUAL_FILE"
  [[ -f "$import_dir/extensions.global-defaults.txt" ]] && cp "$import_dir/extensions.global-defaults.txt" "$GLOBAL_FILE"
  [[ -f "$import_dir/extensions.portable.txt" ]] && cp "$import_dir/extensions.portable.txt" "$PORTABLE_FILE"
  [[ -f "$import_dir/extensions.lock.txt" ]] && cp "$import_dir/extensions.lock.txt" "$LOCK_FILE"
  [[ -f "$import_dir/fonts.required.txt" ]] && cp "$import_dir/fonts.required.txt" "$FONTS_FILE"
  [[ -f "$import_dir/fonts.presence.txt" ]] && cp "$import_dir/fonts.presence.txt" "$FONTS_REPORT_FILE"
  [[ -f "$import_dir/tasks.json" ]] && cp "$import_dir/tasks.json" "${ROOT_DIR}/tasks.json"
  [[ -f "$import_dir/settings.json" ]] && cp "$import_dir/settings.json" "${ROOT_DIR}/settings.json"
  [[ -f "$import_dir/extensions-lean.sh" ]] && cp "$import_dir/extensions-lean.sh" "${ROOT_DIR}/scripts/extensions-lean.sh"
  [[ -f "$import_dir/profile-map.env" ]] && cp "$import_dir/profile-map.env" "$PROFILE_MAP_FILE"
  restore_user_data_roots "$import_dir"

  if [[ "$install_flag" == "install" && -f "$PORTABLE_FILE" ]]; then
    echo "Installing extensions from: $PORTABLE_FILE"
    install_from_list_file "$PORTABLE_FILE"
  elif [[ "$install_flag" == "install-locked" && -f "$LOCK_FILE" ]]; then
    echo "Installing locked extensions from: $LOCK_FILE"
    install_from_lock_file "$LOCK_FILE"
  fi

  echo "Imported bundle from: $src"
  echo "Workspace artifacts updated under: ${ROOT_DIR}"
}

cmd="${1:-help}"

case "$cmd" in
  profile-map-init)
    init_profile_map
    ;;
  sync-publish)
    sync_publish_bundle
    ;;
  export)
    export_extensions
    ;;
  active|index)
    if [[ ! -f "$ALL_FILE" ]]; then
      echo "Missing $ALL_FILE. Run: $0 export" >&2
      exit 1
    fi
    build_active_noncosmetic
    ;;
  visual)
    build_visual_pack
    ;;
  global|defaults)
    build_global_defaults
    ;;
  lean|portable)
    build_portable_pack
    echo "Portable pack includes global defaults + visual pack."
    ;;
  install)
    if [[ ! -f "$PORTABLE_FILE" ]]; then
      echo "Missing $PORTABLE_FILE. Run: $0 portable" >&2
      exit 1
    fi
    install_from_list_file "$PORTABLE_FILE"
    ;;
  lock)
    build_extension_lock
    ;;
  install-locked)
    if [[ ! -f "$LOCK_FILE" ]]; then
      echo "Missing $LOCK_FILE. Run: $0 lock" >&2
      exit 1
    fi
    install_from_lock_file "$LOCK_FILE"
    ;;
  fonts-check)
    build_fonts_presence_report
    ;;
  sync-export)
    sync_export_bundle
    ;;
  sync-import)
    sync_import_bundle "$@"
    ;;
  help|*)
    echo "Usage: $0 {profile-map-init|export|active|visual|global|portable|install|lock|install-locked|fonts-check|sync-export|sync-publish|sync-import}"
    echo "  profile-map-init -> create .vscode/profile-map.env for one-time active profile paths"
    echo "  export  -> write full installed extension list to .vscode/extensions.all.txt"
    echo "  active   -> current non-cosmetic index at .vscode/extensions.active-noncosmetic.txt"
    echo "  visual   -> visual pack (icons/themes) at .vscode/extensions.visual.txt"
    echo "  global   -> recommended default globals at .vscode/extensions.global-defaults.txt"
    echo "  portable -> union of global + visual packs at .vscode/extensions.portable.txt"
    echo "  install  -> install extensions from .vscode/extensions.portable.txt"
    echo "  lock     -> extension lock list with versions at .vscode/extensions.lock.txt"
    echo "  install-locked -> install extensions from .vscode/extensions.lock.txt"
    echo "  fonts-check -> write font presence report at .vscode/fonts.presence.txt"
    echo "  sync-export -> one-command bundle export into .vscode/portable-sync/"
    echo "  sync-publish -> sync-export + copy latest tarball into repo publish folder"
    echo "  sync-import <bundle> [install|install-locked|no-install] -> apply bundle + optionally install extensions"
    echo ""
    echo "Publish env overrides:"
    echo "  SYNC_PUBLISH_REPO_DIR (default: ${PUBLISH_REPO_DIR_DEFAULT})"
    echo "  SYNC_PUBLISH_SUBDIR   (default: ${PUBLISH_SUBDIR_DEFAULT})"
    echo "  SYNC_KEEP_LOCAL       (default: 10)  -> local bundles kept in .vscode/portable-sync/"
    echo "  SYNC_KEEP_PUBLISHED   (default: 3)   -> published tarballs kept in the repo publish folder"
    echo ""
    echo "Tip: .vscode/profile-map.env is auto-loaded for profile path defaults."
    ;;
esac
